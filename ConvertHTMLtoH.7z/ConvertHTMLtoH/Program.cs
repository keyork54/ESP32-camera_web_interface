﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace ConvertHTMLtoH
{
    class Program
    {

        static void Main(string[] args)
        {
            string sourceFile = @"index_ov2640.html";
            string gzFile;
            string outputFile  = @"camera_index.h";
            string zip7 = @".\7z.exe";
            List<string> OutputLines = new List<string>(); ;

            if (args.Length > 0)
            { sourceFile = args[0]; }
            gzFile = sourceFile + ".gz";

            if (File.Exists(zip7))
            {
                using (Process sevenZip = new Process()) //Get 7-Zip to GZip the '.html' file for us
                {
                    sevenZip.StartInfo.FileName = zip7;
                    sevenZip.StartInfo.Arguments = " a -tGZip " + gzFile + " " + sourceFile; //From https://7ziphelp.com/7zip-command-line
                    sevenZip.StartInfo.UseShellExecute = false;
                    sevenZip.StartInfo.RedirectStandardOutput = true;
                    sevenZip.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    sevenZip.StartInfo.CreateNoWindow = true;
                    sevenZip.Start();
                    string output = sevenZip.StandardOutput.ReadToEnd();
                    sevenZip.WaitForExit();
                }
            }
            else
            {
                Console.WriteLine("'{0}' wasn't found. The '7z.exe' utility is required. Please install it", zip7);
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();
                Environment.Exit(1);
            }

            if (File.Exists(gzFile))
            {
                byte[] gzBytes = File.ReadAllBytes(gzFile); // Read the 'gz' file
                string gzLenStr = gzBytes.Length.ToString();
                string gzVarName = gzFile.Replace('.', '_');

                OutputLines.Add(""); //This line blank
                OutputLines.Add(@"//File: " + gzFile + ", Size: " + gzLenStr); //This is the File comment
                OutputLines.Add("#define " + gzVarName + "_len " + gzLenStr); //This is the 'define' line
                OutputLines.Add("const uint8_t " + gzVarName + "[] = {"); //This is the 'const unint8_t' line

                int gzIndex, lineItem = 1;
                string dataLine = "";

                for (gzIndex = 0; gzIndex < gzBytes.Length - 1; gzIndex++)
                {
                    dataLine += String.Format(" 0x{0:X2},", gzBytes[gzIndex]);
                    if (++lineItem > 16)
                    {
                        OutputLines.Add(dataLine);
                        lineItem = 1;
                        dataLine = "";
                    }
                }
                dataLine += String.Format(" 0x{0:X2}", gzBytes[gzIndex]); //This is the last byte, it doesn't have a trailing ','
                OutputLines.Add(dataLine);

                OutputLines.Add("};"); //This is the final line
            }

            using(StreamWriter streamWriter = File.CreateText(outputFile))
            {
                foreach(string line in OutputLines)
                { streamWriter.WriteLine(line); }
            }
        }
    }
}
