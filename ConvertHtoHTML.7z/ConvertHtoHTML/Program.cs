﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;

namespace ConvertHtoHTML
{
    class Program
    {

        static void Main(string[] args)
        {
            string sourceFile = @"camera_index.h";
            string outputFile = @"index_ov2640_html.gz";
            List<byte> sourceBytes = new List<byte>(); ;

            if (args.Length > 0)
            { sourceFile = args[0]; }

            if (File.Exists(sourceFile))
            {
                using (StreamReader fileReader = new StreamReader(sourceFile)) // Read the 'h' file
                {
                    string sourceLine1, sourceLine2, sourceLine3, sourceLine4, nextLine;
                    string[] fileLine, sourceLine;
                    ByteConverter byteConverter = new ByteConverter(); //ByteConverter handles ' 0xNN' format

                    sourceLine1 = fileReader.ReadLine(); //This is blank
                    sourceLine2 = fileReader.ReadLine(); //This is the File comment
                    sourceLine3 = fileReader.ReadLine(); //This is the Define line
                    sourceLine4 = fileReader.ReadLine(); //This is the const unint8_t line

                    fileLine = sourceLine2.Split(',', ' ');
                    outputFile = fileLine[1]; //Ensure the output file matches what is in the input file

                    while ((nextLine = fileReader.ReadLine()).Length > 2) //Ignore the last line '};'
                    {
                        sourceLine = nextLine.Split(',');
                        foreach (string data in sourceLine) //Convert each string of byte-data to byte
                        {
                            if (data.Length > 0) //There is an extra, empty string at at the end of sourceLine
                            { sourceBytes.Add((byte)byteConverter.ConvertFromString(data)); }
                        }
                    }
                }
            }
            using (BinaryWriter binWriter = new BinaryWriter(File.Open(outputFile, FileMode.Create))) //Re-create the '.gz' file
            {
                foreach (byte sourceByte in sourceBytes)
                { binWriter.Write(sourceByte); }
            }
            // From https://stackoverflow.com/questions/3173775/how-to-run-external-program-via-a-c-sharp-program
            using (Process sevenZip = new Process()) //Get 7-Zip to extract the '.html' file for us
            {
                sevenZip.StartInfo.FileName = @".\7z.exe";
                sevenZip.StartInfo.Arguments = "e -y " + outputFile; //From https://7ziphelp.com/7zip-command-line
                sevenZip.StartInfo.UseShellExecute = false;
                sevenZip.StartInfo.RedirectStandardOutput = true;
                sevenZip.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                sevenZip.StartInfo.CreateNoWindow = true;
                sevenZip.Start();
                string output = sevenZip.StandardOutput.ReadToEnd();
                sevenZip.WaitForExit();
            }
        }
    }
}
